/*
	Constants, types, and structures used for the Fool Lanterns
*/
typedef struct LED_Command_t {
	enum		{MODE_GLOBAL, MODE_PEER_TO_PEER} mode;
	enum		{SUBMODE_FIXED, SUBMODE_RANDOM} subMode;
	uint8_t		redIntensity;		// Red value for all LEDs
	uint8_t		grnIntensity;		// Green value for all LEDs
	uint8_t		bluIntensity;		// Blue value for all LEDs
	uint8_t		period_mS;			// mS
} LED_Command_t;

// App endpoints
#define LEDCmd_ENDPOINT				1
#define Mote_Addr_ENDPOINT			16

#define BROADCAST_ADDR				0xFFFF